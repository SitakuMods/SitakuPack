# SitakuPack
This is the GitHub page for the official Sitaku Texture Pack. Releases can be accessed on the tab on the right or on the corresponding tab.

From now onwards, all copies of the Sitaku Pack will be uploaded to GitHub for collaboration purposes as well as easy access to all files, rather than using Google Drive or Dropbox, although Dropbox will be used to store server pack files.
